

library("ggmcmc")
library("jagsUI")
library("tidyverse")

mate.advantage.data<-read_csv("mate.advantage.data.csv")%>%select(-c("...1"))
summary(mate.advantage.data)


parametersosintg.sig <- c(
  "alpha","betapest","betaguard","betastate","betaorder"
  ,"epsF", "epsM", "epsO", "WAIC","Fit", "FitNew")

inits0g <- function(){list(alpha=runif(1),
                           betastate=runif(1),
                           betaguard=runif(1),
                           betapest=runif(1),
                           betaorder=runif(1)
)}





meanorder=mean(mate.advantage.data$dayjoinedcomp)
sdorder = sd(mate.advantage.data$dayjoinedcomp)
recoverorder <- function(x){(sdorder*(x))+meanorder}
standorder<-function(x){(x-meanorder)/sdorder}

meanpest=mean(mate.advantage.data$n_pesterer)
sdpest = sd(mate.advantage.data$n_pesterer)
recoverpest <- function(x){(sdpest*(x))+meanpest}
standpest<-function(x){(x-meanpest)/sdpest}

meanguard=mean(mate.advantage.data$n_guards)
sdguard = sd(mate.advantage.data$n_guards)
recoverguard <- function(x){(sdguard*(x))+meanguard}
standguard<-function(x){(x-meanguard)/sdguard}


jags.data.fit0gp.compadjust <- list( y = mate.advantage.data$diad.success.binom,n = length(mate.advantage.data$diad.success.binom),
                                     guard = standguard(mate.advantage.data$n_guards),
                                     pest= standpest(mate.advantage.data$n_pesterer),
                                     order = standorder(mate.advantage.data$dayjoinedcomp),
                                     #cindex=mate.advantage.data$femcomp.av.guardpestindex.oes,
                                     state=mate.advantage.data$staten,
                                     code = mate.advantage.data$coden,
                                     male = mate.advantage.data$malen,
                                     fem = mate.advantage.data$femn,
                                     codel= length(levels(as.factor(round(mate.advantage.data$coden)))),
                                     malel= length(levels(as.factor(round(mate.advantage.data$malen)))),
                                     feml= length(levels(as.factor(round(mate.advantage.data$femn)))))




sink("model.txt")
cat("
model {
for (i in 1:n){
y[i] ~ dbern(p[i]) # GLM with a bernouli distribution
logit(p[i]) <- z[i]
z[i] <- alpha
+betaguard*guard[i]#  Specifying the fit of the linear model (fixed effects)
+betapest*pest[i]
+betastate*state[i]
+betaorder*order[i]
+epsF[fem[i]]# Specifying the fit of the linear model (random effects)
+epsM[male[i]]
+epsO[code[i]]
}
alpha ~ dnorm(0, .001)# Specifying priors
betaguard ~ dnorm(0, .001)
betapest ~ dnorm(0, .001)
betastate ~ dnorm(0, .001)
betaorder~ dnorm(0, .001)

tau.oc <- 1 / (sd.oc*sd.oc)
sd.oc ~ dunif(0, 1)
tau.m <- 1 / (sd.m*sd.m)
sd.m ~ dunif(0, 1)
tau.f <- 1 / (sd.f*sd.f)
sd.f ~ dunif(0, 1)



for(i in 1:codel){
epsO[i]~ dnorm(0,tau.oc)}
for(i in 1:malel){
epsM[i]~ dnorm(0,tau.m)}
for(i in 1:feml){
epsF[i]~ dnorm(0,tau.f)}
}
")
sink()

ni <-100000
nt <- 300
nb <-1000
nc <- 3

getwd()


model<-jagsUI ::jags(jags.data.fit0gp.compadjust, inits0g, parametersosintg.sig, "model.txt", n.chains = nc, n.thin = nt, n.iter = ni, n.burnin = nb,parallel=TRUE,DIC=T)




model#rhat (convergence) is <1.1 for all variables



ggfit<-ggs(model$samples)
ggfitnor<-filter(ggfit, !grepl('eps', Parameter), !grepl('Fit', Parameter), !grepl('deviance', Parameter), !grepl('alpha', Parameter))#Selecting only fixed parameter estimates
ggs_compare_partial(ggfitnor)#compares whole chain with the last value
ggs_autocorrelation(ggfitnor)#Autocorelation plot
ggs_traceplot(ggfitnor)#Traceplot showing convergence
ggs_crosscorrelation(ggfitnor)#check for highly correlated dependent variables (deep blue or red)




ggs_caterpillar(ggfitnor)+xlim(-5,5)+ geom_vline(xintercept = 0)+theme_classic()

ggs_density(ggfitnor, hpd=TRUE)+xlim(-5,5)+ geom_vline(xintercept = 0)+theme_classic()+facet_wrap(~ Parameter, nrow = 4)+labs(y="Posteior samples")

